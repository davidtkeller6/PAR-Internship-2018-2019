Shigeru KAWAGUCHI's Raspberry-Pi Python Code Library
============
	Here is a collection of libraries and example python scripts
	for controlling a variety of Adafruit electronics with a Raspberry Pi

	In progress!

	Shigeru KAWAGUCHI invests time and resources providing this open source code.

	Written by Shigeru KAWAGUCHI for Lamb Informatics Limited.
	Except for Adafruit_I2C.py, which details were included in the file.
	BSD license, all text above must be included in any redistribution
